package com.example.jobportal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CompanyRegisterActivity extends AppCompatActivity {
    EditText username, email, password, cnfmpassword;
    Button register;
    TextView loginc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_register);
        username = (EditText) findViewById(R.id.Username);
        email = (EditText) findViewById(R.id.inputEmail);
        password = (EditText) findViewById(R.id.inputPassword);
        cnfmpassword = (EditText) findViewById(R.id.ConfirmPassword);
        register = (Button) findViewById(R.id.btnregister);
        loginc= (TextView) findViewById(R.id.txt_login);
        TextView btn = findViewById(R.id.alreadyhaveAccount);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(com.example.jobportal.CompanyRegisterActivity.this, CompanyActivity.class);
                startActivity(intent);
            }
        });
        loginc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(com.example.jobportal.CompanyRegisterActivity.this,CompanyLoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
