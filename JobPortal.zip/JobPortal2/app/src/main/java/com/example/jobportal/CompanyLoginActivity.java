package com.example.jobportal;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CompanyLoginActivity extends AppCompatActivity {
    TextView signupc, Forgotpassword;
    Button login;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_login);
        login = (Button) findViewById(R.id.btnlogin);
        signupc = (TextView) findViewById(R.id.textViewSignUp);
        Forgotpassword = (TextView) findViewById(R.id.forgotPassword);
        builder = new AlertDialog.Builder(this);
        signupc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CompanyLoginActivity.this,CompanyRegisterActivity.class));
            }
        });
        Forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Uncomment the below code to Set the message and title from the strings.xml file
                final EditText resetMail = new EditText(v.getContext());
                builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);
                builder.setView(resetMail);
                //Setting message manually and performing action on button click
                builder.setMessage("Enter your mail id:")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Toast.makeText(getApplicationContext(),"Check your mail inbox",
                                        Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();

                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("Forgot Password?");
                alert.show();
            }
        });
    }
}